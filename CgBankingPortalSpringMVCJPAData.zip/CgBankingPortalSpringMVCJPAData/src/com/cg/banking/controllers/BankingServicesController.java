package com.cg.banking.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServiceDownException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServices;

@Controller
public class BankingServicesController {
	@Autowired
	BankingServices services;

	@RequestMapping("/registerAccount")
	public ModelAndView getRegisterAccount(@ModelAttribute Account account)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServiceDownException {
		account = services.openAccount(account);
		return new ModelAndView("openAccountSuccess", "account", account);
	}
	
	  @RequestMapping("/depositAmount") 
	  public ModelAndView getDepositAmount(@RequestParam long accountNo, @RequestParam float amount) throws AccountNotFoundException,
	  BankingServiceDownException, AccountBlockedException 
	  { 
		  float updatedBalance = services.depositAmount(accountNo,amount); 
		  return new  ModelAndView("getDepositAmount","account",updatedBalance);
	  }
}
