package com.cg.banking.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;

@Controller
public class URIController
{
	private Account account;
	private Transaction transaction;
   @RequestMapping("/")
   public String getIndexPage()
   {
	   return "indexPage";
   }
   
   @RequestMapping("/openAccount")
   public String getOpenAccount()
   {
	   return "openAccount";
   }
   @RequestMapping("/getDepositAmount")
   public String getDeposit()
   {
	   return "getDepositAmount";
   }
   @ModelAttribute
   public Account getAccount()
	{
		account = new Account();
		return account;
	}
   @ModelAttribute
   public Transaction getTransaction()
   {
	   transaction = new Transaction();
	   return transaction;
   }

}
